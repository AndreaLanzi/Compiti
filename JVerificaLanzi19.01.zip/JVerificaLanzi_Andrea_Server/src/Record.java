
public class Record {
	public String nomeArticolo, prezzoPartenza, prezzoFinale, nomeAcquirente;
	
	public Record(String nomeArticolo, String prezzoPartenza, String prezzoFinale, String nomeAcquirente)
	{
		this.nomeArticolo=nomeArticolo;
		this.prezzoPartenza=prezzoPartenza;
		this.prezzoFinale=prezzoFinale;
		this.nomeAcquirente=nomeAcquirente;
	}
}
